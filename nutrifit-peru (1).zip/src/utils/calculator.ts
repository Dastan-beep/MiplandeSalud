import { FitnessGoal, FoodItem, LifestyleLevel, MacroGoals, RecipeIngredient, UserProfile } from '../types/nutrition';

export const LS_FACTORS: Record<LifestyleLevel, number> = {
  sedentario: 1.2,
  ligero: 1.375,
  moderado: 1.55,
  activo: 1.725,
  deportista: 1.9,
  embarazo: 1.35,
};

// Protein target grams per kg of body weight
export const PROT_TARGET_PER_KG: Record<FitnessGoal, Record<LifestyleLevel, number>> = {
  perdida: {
    sedentario: 1.5,
    ligero: 1.7,
    moderado: 1.9,
    activo: 2.1,
    deportista: 2.3,
    embarazo: 1.5,
  },
  ganancia: {
    sedentario: 1.6,
    ligero: 1.8,
    moderado: 2.0,
    activo: 2.1,
    deportista: 2.2,
    embarazo: 1.6,
  },
};

export function calculateIMC(peso: number, tallaCm: number): number {
  if (!tallaCm || !peso) return 0;
  const meters = tallaCm / 100;
  return +(peso / (meters * meters)).toFixed(1);
}

export function getImcClassification(imc: number): { label: string; color: string } {
  if (imc < 18.5) return { label: 'Bajo peso', color: 'text-amber-600' };
  if (imc < 25) return { label: 'Peso saludable ✓', color: 'text-emerald-700' };
  if (imc < 30) return { label: 'Sobrepeso', color: 'text-amber-700' };
  return { label: 'Obesidad', color: 'text-rose-700' };
}

export function calculateTDEE(peso: number, talla: number, edad: number, ls: LifestyleLevel): number {
  // Mifflin-St Jeor
  const bmr = 10 * peso + 6.25 * talla - 5 * edad - 161; // Female baseline / average
  const factor = LS_FACTORS[ls] || 1.375;
  return Math.round(bmr * factor);
}

export function computeGoalMacros(
  peso: number,
  talla: number,
  edad: number,
  ls: LifestyleLevel,
  goal: FitnessGoal
): { macros: MacroGoals; tdee: number; calorieDelta: number } {
  const tdee = calculateTDEE(peso, talla, edad, ls);

  let targetKcal = tdee;
  let calorieDelta = 0;

  if (goal === 'perdida') {
    // 20% deficit or max 500 kcal
    calorieDelta = -Math.min(500, Math.round(tdee * 0.20));
    targetKcal = Math.max(1250, tdee + calorieDelta);
  } else {
    // Muscle gain: lean surplus +250 to +350 kcal
    calorieDelta = Math.round(tdee * 0.12);
    targetKcal = tdee + calorieDelta;
  }

  // Protein
  const protPerKg = PROT_TARGET_PER_KG[goal][ls] || (goal === 'perdida' ? 1.8 : 1.9);
  const protGrams = Math.round(peso * protPerKg);
  const protKcal = protGrams * 4;

  // Fats: 25% of calories in fat loss, 28% in muscle gain
  const fatPct = goal === 'perdida' ? 0.25 : 0.27;
  const fatKcal = Math.round(targetKcal * fatPct);
  const fatGrams = Math.round(fatKcal / 9);

  // Carbs: remaining calories
  const carbKcal = Math.max(200, targetKcal - protKcal - fatKcal);
  const carbGrams = Math.round(carbKcal / 4);

  return {
    macros: {
      kcal: targetKcal,
      prot: protGrams,
      carb: carbGrams,
      gras: fatGrams,
    },
    tdee,
    calorieDelta,
  };
}

export function calculateIngredientMacros(ingredient: RecipeIngredient, grams: number) {
  const ratio = grams / 100;
  return {
    grams,
    kcal: Math.round(ingredient.kcalPer100g * ratio),
    p: +(ingredient.protPer100g * ratio).toFixed(1),
    c: +(ingredient.carbPer100g * ratio).toFixed(1),
    g: +(ingredient.grasPer100g * ratio).toFixed(1),
  };
}

export function calculateCompositeTotals(ingredients: RecipeIngredient[]) {
  return ingredients.reduce(
    (acc, ing) => {
      const macros = calculateIngredientMacros(ing, ing.currentGrams);
      return {
        kcal: acc.kcal + macros.kcal,
        p: +(acc.p + macros.p).toFixed(1),
        c: +(acc.c + macros.c).toFixed(1),
        g: +(acc.g + macros.g).toFixed(1),
        totalGrams: acc.totalGrams + ing.currentGrams,
      };
    },
    { kcal: 0, p: 0, c: 0, g: 0, totalGrams: 0 }
  );
}

export function calculateLabelMacros(
  basis: '100g' | 'serving',
  servingGrams: number,
  kcal: number,
  prot: number,
  carb: number,
  gras: number,
  consumedGrams: number
) {
  const referenceGrams = basis === '100g' ? 100 : (servingGrams || 100);
  const ratio = consumedGrams / referenceGrams;

  return {
    consumedGrams,
    kcal: Math.round(kcal * ratio),
    p: +(prot * ratio).toFixed(1),
    c: +(carb * ratio).toFixed(1),
    g: +(gras * ratio).toFixed(1),
  };
}
